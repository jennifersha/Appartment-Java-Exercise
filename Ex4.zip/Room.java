public class Room {
	// the properties of the Room
	private String type;
	private double area;

	public Room(String type, double area) {
		this.type=type; 
		if(area<0) { 
		// if the area of the Room smaller than 0 then the area will be=0
			this.area=0;
		}
		else { //anything else then it gives us the area
			this.area=area;
		}
	}
	public Room(Room other) { // here other Room
		type=other.type;
		area=other.area;
	}
	public String getType() { // return the name of the Room
		return this.type;
	}
	public void setType(String name) { //place or set the name of the Room
		this.type = name;
	}
	public double getArea() { //return the area of the Room
		return this.area;
	}
	public String toString() { //return the Room by this format:
		return "room type:"+(type)+",Area:"+(area);
	}

}
