public class Apartment {
	// the properties
	private String family;
	private int flat;
	private Room firstRoom;
	private Room secondRoom;
	private Room thirdRoom;
	private int numOfRooms;

	public Apartment(String name, int flat) { 
		//The builder initializes the family name and flat.
		this.family=name;
		this.flat=flat;
		this.firstRoom=null;
		this.secondRoom=null;
		this.thirdRoom=null;
		this.numOfRooms=0;

		if(flat<0) {
			this.flat=0;
		}
		else {
			this.flat=flat;
		}
	}
	public String getFamily() { // return the name of the family
		return family;
	}
	public int getFlat() { //return the flat
		return flat;
	}
	public int getnumOfRoom() { //return number of rooms
		return numOfRooms;
	}
	public Room getRoomByType(String type) { 
		//The method returns a Room type object whose type is Type.
		//If there is no such room, the method returns null.
		if(firstRoom !=null && firstRoom.getType()==type) {
			return new Room(firstRoom);}

		else if(secondRoom !=null && secondRoom.getType()==type) {
			return new Room(secondRoom);}
		
		else if(thirdRoom !=null && thirdRoom.getType()==type) {
			return new Room(thirdRoom);}
		
		else return null;
	}
	public void setRoom(Room r) { 

//If the method already has three booted rooms, the method will do nothing. 
		//If one or more of the rooms is not yet initialized, 
		//the method will set r to one, no matter which one.
		if (firstRoom ==null) {
			this.firstRoom=new Room(r);
			numOfRooms++;
		}
		else if (secondRoom == null) {
			this.secondRoom = new Room (r);
			numOfRooms++;
		}
		else if (thirdRoom == null) {
			this.thirdRoom=new Room(r);
			numOfRooms++;
		}
	}
	public double getTotalArea() { // return the total Area
		double total= this.firstRoom.getArea()+this.secondRoom.getArea()
		+this.thirdRoom.getArea();
		return total;
	}
	public String toString() { // it returns string with this format:
		String s= (family)+"'s appartment , flat "+(flat)+" has "
				+(numOfRooms)+" rooms";
		if(this.firstRoom!=null) {
			s=s+"\n"+ this.firstRoom.toString();
		}
		if(this.secondRoom!=null) {
			s=s+"\n"+ this.secondRoom.toString();
		}
		if(this.thirdRoom!=null) {
			s=s+"\n"+ this.thirdRoom.toString();
		}
		return s;

	}
}
